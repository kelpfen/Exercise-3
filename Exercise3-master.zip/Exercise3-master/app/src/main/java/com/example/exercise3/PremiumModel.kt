package com.example.exercise3

import androidx.lifecycle.ViewModel

class PremiumModel : ViewModel(){

    var premiumModel: Double = 0.0
}